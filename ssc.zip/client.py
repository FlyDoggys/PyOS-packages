import argparse
import socket

def connect_to_server(address, port):
    client = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    try:
        client.connect((address, port))
        print(f"Connected to server at {address}:{port}")
    except Exception as e:
        print(f"Connection failed: {e}")
    finally:
        client.close()

def main():
    parser = argparse.ArgumentParser(description='Client for connecting to a server.')
    parser.add_argument('--port', type=int, required=True, help='Port number to connect to')
    args = parser.parse_args()

    # Вызываем функцию connect_to_server с указанным портом
    connect_to_server('localhost', args.port)

if __name__ == "__main__":
    main()
