import socket
import os
import random

def create_server():
    host = '0.0.0.0'
    port = 8700 + random.randint(0, 99)

    server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    server.bind((host, port))
    print(f"Server started on port {port}")

    while True:
        server.listen(1)
        conn, addr = server.accept()
        print(f"Connected by {addr}")

        start_pyos()

        conn.close()

def start_pyos():
    os.system("start cmd /c C:\\PyOS\\PyOS.exe")
    
create_server()    
